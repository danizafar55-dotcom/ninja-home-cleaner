import { GoogleGenAI, Type } from "@google/genai";
import { CleaningGuidance } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export async function generateCleaningGuidance(problem: string): Promise<CleaningGuidance> {
  const model = "gemini-3-flash-preview";
  
  const systemInstruction = `You are "Ninja Home Cleaner", an expert AI cleaning assistant specialized in natural, chemical-free cleaning solutions and ancient civilization cleaning wisdom.
  Your tone is simple, helpful, practical, and slightly engaging like a "home expert".
  Focus on real-life usable solutions. No chemicals mixing that can be harmful.
  
  Format your response as a structured JSON object matching the CleaningGuidance interface.`;

  const response = await ai.models.generateContent({
    model,
    contents: `User cleaning problem: ${problem}`,
    config: {
      systemInstruction,
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          problemAnalysis: {
            type: Type.STRING,
            description: "Briefly explain what the problem is and why it happens in 1–2 lines."
          },
          naturalMethods: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                title: { type: Type.STRING },
                instructions: { 
                  type: Type.ARRAY, 
                  items: { type: Type.STRING },
                  description: "Step-by-step instructions"
                },
                ingredients: { 
                  type: Type.ARRAY, 
                  items: { type: Type.STRING },
                  description: "Simple household items"
                },
                tip: { type: Type.STRING, description: "Short tip for better result" }
              },
              required: ["title", "instructions", "ingredients", "tip"]
            },
            description: "Provide 5 DIFFERENT natural, chemical-free cleaning methods."
          },
          ancientSecrets: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                civilization: { type: Type.STRING, description: "Example: Romans, Egyptians, etc." },
                ingredients: { type: Type.STRING, description: "What they used for cleaning" },
                howToUse: { type: Type.STRING, description: "How they used it (step by step simple explanation)" },
                whyItWorked: { type: Type.STRING, description: "Why it worked (short explanation)" }
              },
              required: ["civilization", "ingredients", "howToUse", "whyItWorked"]
            },
            description: "Provide 2 historical cleaning methods used by ancient civilizations."
          },
          safetyTip: {
            type: Type.STRING,
            description: "Give one short safety warning if needed."
          }
        },
        required: ["problemAnalysis", "naturalMethods", "ancientSecrets", "safetyTip"]
      }
    }
  });

  const text = response.text;
  if (!text) {
    throw new Error("No response from Ninja Home Cleaner.");
  }

  return JSON.parse(text) as CleaningGuidance;
}
